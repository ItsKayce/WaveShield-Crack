RegisterCommand("anticheat",function(source)  --ANTI RESOURCE STOP
end)

Deluxe = {}
Deluxe.Math = {}
Deer = {}
Plane = {}
e = {}
Lynx8 = {}
LynxEvo = {}
MaestroMenu = {}
Motion = {}
TiagoMenu = {}
gaybuild = {}
Cience = {}
LynxSeven = {}
SwagUI = {}
WarMenu = {}
MMenu = {}
FantaMenuEvo = {}
Dopamine = {}
GRubyMenu = {}
LR = {}
BrutanPremium = {}
LuxUI = {}
HamMafia = {}
InSec = {}
AlphaVeta = {}
KoGuSzEk = {}
ShaniuMenu = {}
LynxRevo = {}
ariesMenu = {}
dexMenu = {}
HamHaxia = {}
Ham = {}
b00mek = {}
Biznes = {}
FendinXMenu = {}
AlphaV = {}
NyPremium = {}
falcon = {}
Falcon = {}
Test = {}
Nisi = {}
gNVAjPTvr3OF = {}
AKTeam = {}
a = {}
FrostedMenu = {}
lynxunknowncheats = {}
ATG = {}
fuckYouCuntBag = {}
Absolute = {}
FalloutMenu = {}

local r4uyKLTGzjx_Ejh0 = {
[1] = nil,
[2] = nil,
[3] = nil,
[4] = nil
}

local ____ = {
[1] = nil,
[2] = nil,
[3] = nil,
[4] = nil,
[5] = nil,
[6] = nil,
[7] = nil,
[8] = nil,
[9] = nil,
[10] = nil,
[11] = "waveshieldbetterthanyounoob",
[12] = "waveshieldbetterthanyounoob"
}

Wf = "waveshieldbetterthanyounoob"
OAf14Vphu3V = "waveshieldbetterthanyounoob"
iJ = "waveshieldbetterthanyounoob"
pcwCmJS = "waveshieldbetterthanyounoob"
gNVAjPTvr3OF.SubMenu = "waveshieldbetterthanyounoob"
Falcon.CreateMenu = "waveshieldbetterthanyounoob"
falcon.CreateMenu = "waveshieldbetterthanyounoob"
___ = "waveshieldbetterthanyounoob"
_________ = "waveshieldbetterthanyounoob"
WJPZ = "waveshieldbetterthanyounoob"
Crazymodz = "waveshieldbetterthanyounoob"
Plane = "waveshieldbetterthanyounoob"
Proxy = "waveshieldbetterthanyounoob"
xseira = "waveshieldbetterthanyounoob"
Cience = "waveshieldbetterthanyounoob"
KoGuSzEk = "waveshieldbetterthanyounoob"
Deluxe.Math.Round = "waveshieldbetterthanyounoob"
LynxEvo = "waveshieldbetterthanyounoob"
nkDesudoMenu = "waveshieldbetterthanyounoob"
JokerMenu = "waveshieldbetterthanyounoob"
moneymany = "waveshieldbetterthanyounoob"
dreanhsMod = "waveshieldbetterthanyounoob"
gaybuild = "waveshieldbetterthanyounoob"
Lynx7 = "waveshieldbetterthanyounoob"
LynxSeven = "waveshieldbetterthanyounoob"
TiagoMenu = "waveshieldbetterthanyounoob"
GrubyMenu = "waveshieldbetterthanyounoob"
SkazaMenu = "waveshieldbetterthanyounoob"
BlessedMenu = "waveshieldbetterthanyounoob"
AboDream = "waveshieldbetterthanyounoob"
MaestroMenu = "waveshieldbetterthanyounoob"
sixsixsix = "waveshieldbetterthanyounoob"
GrayMenu = "waveshieldbetterthanyounoob"
Menu = "waveshieldbetterthanyounoob"
YaplonKodEvo = "waveshieldbetterthanyounoob"
Biznes = "waveshieldbetterthanyounoob"
FantaMenuEvo = "waveshieldbetterthanyounoob"
LoL = "waveshieldbetterthanyounoob"
BrutanPremium = "waveshieldbetterthanyounoob"
UAE = "waveshieldbetterthanyounoob"
xnsadifnias = "waveshieldbetterthanyounoob"
TAJNEMENUMenu = "waveshieldbetterthanyounoob"
Outcasts666 = "waveshieldbetterthanyounoob"
HamMafia = "waveshieldbetterthanyounoob"
b00mek = "waveshieldbetterthanyounoob"
FlexSkazaMenu = "waveshieldbetterthanyounoob"
Desudo = "waveshieldbetterthanyounoob"
AlphaVeta = "waveshieldbetterthanyounoob"
nietoperek = "waveshieldbetterthanyounoob"
bat = "waveshieldbetterthanyounoob"
OneThreeThreeSevenMenu = "waveshieldbetterthanyounoob"
jebacDisaMenu = "waveshieldbetterthanyounoob"
lynxunknowncheats = "waveshieldbetterthanyounoob"
Motion = "waveshieldbetterthanyounoob"
onionmenu = "waveshieldbetterthanyounoob"
onion = "waveshieldbetterthanyounoob"
onionexec = "waveshieldbetterthanyounoob"
frostedflakes = "waveshieldbetterthanyounoob"
AlwaysKaffa = "waveshieldbetterthanyounoob"
skaza = "waveshieldbetterthanyounoob"
b00mMenu = "waveshieldbetterthanyounoob"
reasMenu = "waveshieldbetterthanyounoob"
ariesMenu = "waveshieldbetterthanyounoob"
MarketMenu = "waveshieldbetterthanyounoob"
LoverMenu = "waveshieldbetterthanyounoob"
dexMenu = "waveshieldbetterthanyounoob"
nigmenu0001 = "waveshieldbetterthanyounoob"
rootMenu = "waveshieldbetterthanyounoob"
Genesis = "waveshieldbetterthanyounoob"
Tuunnell = "waveshieldbetterthanyounoob"
HankToBallaPool = "waveshieldbetterthanyounoob"
Roblox = "waveshieldbetterthanyounoob"
scroll = "waveshieldbetterthanyounoob"
zzzt = "waveshieldbetterthanyounoob"
werfvtghiouuiowrfetwerfio = "waveshieldbetterthanyounoob"
llll4874 = "waveshieldbetterthanyounoob"
KAKAAKAKAK = "waveshieldbetterthanyounoob"
udwdj = "waveshieldbetterthanyounoob"
Ggggg = "waveshieldbetterthanyounoob"
jd366213 = "waveshieldbetterthanyounoob"
KZjx = "waveshieldbetterthanyounoob"
ihrug = "waveshieldbetterthanyounoob"
WADUI = "waveshieldbetterthanyounoob"
Crusader = "waveshieldbetterthanyounoob"
FendinX = "waveshieldbetterthanyounoob"
oTable = "waveshieldbetterthanyounoob"
LeakerMenu = "waveshieldbetterthanyounoob"
nukeserver = "waveshieldbetterthanyounoob"
esxdestroyv2 = "waveshieldbetterthanyounoob"
teleportToNearestVehicle = "waveshieldbetterthanyounoob"
AddTeleportMenu = "waveshieldbetterthanyounoob"
AmbulancePlayers = "waveshieldbetterthanyounoob"
Aimbot = "waveshieldbetterthanyounoob"
CrashPlayer = "waveshieldbetterthanyounoob"
RapeAllFunc = "waveshieldbetterthanyounoob"




LobatL = "waveshieldbetterthanyounoob"
lua = "waveshieldbetterthanyounoob"
aimbot = "waveshieldbetterthanyounoob"
malicious = "waveshieldbetterthanyounoob"
salamoonder = "waveshieldbetterthanyounoob"
watermalone = "waveshieldbetterthanyounoob"
neodymium = "waveshieldbetterthanyounoob"
baboon = "waveshieldbetterthanyounoob"
bab00n = "waveshieldbetterthanyounoob"
sam772 = "waveshieldbetterthanyounoob"
dopamine = "waveshieldbetterthanyounoob"
dopameme = "waveshieldbetterthanyounoob"
cheat = "waveshieldbetterthanyounoob"
eulen = "waveshieldbetterthanyounoob"
onion = "waveshieldbetterthanyounoob"
skid = "waveshieldbetterthanyounoob"
redst0nia = "waveshieldbetterthanyounoob"
redstonia = "waveshieldbetterthanyounoob"
injected = "waveshieldbetterthanyounoob"
resources = "waveshieldbetterthanyounoob"
execution = "waveshieldbetterthanyounoob"
static = "waveshieldbetterthanyounoob"
d0pa = "waveshieldbetterthanyounoob"
dimitri = {}
dimitri.porn = "waveshieldbetterthanyounoob"
tiago = "waveshieldbetterthanyounoob"
tapatio = "waveshieldbetterthanyounoob"
balla = "waveshieldbetterthanyounoob"
FirePlayers = "waveshieldbetterthanyounoob"
ExecuteLua = "waveshieldbetterthanyounoob"
TSE = "waveshieldbetterthanyounoob"
GateKeep = "waveshieldbetterthanyounoob"
ShootPlayer = "waveshieldbetterthanyounoob"
InitializeIntro = "waveshieldbetterthanyounoob"
tweed = "waveshieldbetterthanyounoob"
GetResources = "waveshieldbetterthanyounoob"
PreloadTextures = "waveshieldbetterthanyounoob"
CreateDirectory = "waveshieldbetterthanyounoob"
WMGang_Wait = "waveshieldbetterthanyounoob"
capPa = "waveshieldbetterthanyounoob"
cappA = "waveshieldbetterthanyounoob"
Resources = "waveshieldbetterthanyounoob"
defaultVehAction = "waveshieldbetterthanyounoob"
ApplyShockwave = "waveshieldbetterthanyounoob"
badwolfMenu = "waveshieldbetterthanyounoob"
IlIlIlIlIlIlIlIlII = "waveshieldbetterthanyounoob"
AlikhanCheats = "waveshieldbetterthanyounoob"
chujaries = "waveshieldbetterthanyounoob"
menuName = "waveshieldbetterthanyounoob"
NertigelFunc = "waveshieldbetterthanyounoob"
WM2 = "waveshieldbetterthanyounoob"
wmmenu = "waveshieldbetterthanyounoob"
redMENU = "waveshieldbetterthanyounoob"
bps = "waveshieldbetterthanyounoob"


Falcon = "waveshieldbetterthanyounoob"
falcon = "waveshieldbetterthanyounoob"
a = "waveshieldbetterthanyounoob"
FrostedMenu = "waveshieldbetterthanyounoob"
ATG = "waveshieldbetterthanyounoob"
fuckYouCuntBag = "waveshieldbetterthanyounoob"
Absolute = "waveshieldbetterthanyounoob"


Citizen.CreateThread(function()


    Citizen.Wait(2000)

    while true do
        Citizen.Wait(2000)
        if Falcon ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Falcon")
        end 
        if  falcon ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Falcon")
        end 
        if  a ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."a")
        end 
        if  FrostedMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."FrostedMenu")
        end 
        if  ATG ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."ATG")
        end 
        if  fuckYouCuntBag ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."fuckYouCuntBag")
        end 
        if  Absolute ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Absolute")
        end 
        if  bps ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."bps")
        end 
        if  r4uyKLTGzjx_Ejh0[4] ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."r4uyKLTGzjx_Ejh0")
        end 
        if  r4uyKLTGzjx_Ejh0[2] ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."r4uyKLTGzjx_Ejh0")
        end 
        if  ____[11] ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."RedStonia")
        end 
        if  ___ ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."RedStonia")
        end 
        if  _________ ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."RedStonia")
        end 
        if  WJPZ ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."RedStonia")
        end 
        if  Wf ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."RedStonia")
        end 
        if  OAf14Vphu3V ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."RedStonia")
        end 
        if  iJ ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."RedStonia")
        end 
        if  pcwCmJS ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."RedStonia")
        end 
        if  gNVAjPTvr3OF.SubMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."RedStonia")
        end 
        if  Deluxe.Math.Round ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."RedStonia")
        end

        if Plane ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Plane")
        end 
        if  Cience ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Cience")
        end 
        if  KoGuSzEk ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."KoGuSzEk")
        end 
        if  LynxEvo ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."LynxEvo")
        end 
        if  gaybuild ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."gaybuild")
        end 
        if  LynxSeven ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."LynxSeven")
        end 
        if  TiagoMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."TiagoMenu")
        end 
        if  GrubyMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."GrubyMenu")
        end 
        if  MaestroMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."MaestroMenu")
        end 
        if  Biznes ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Biznes")
        end 
        if  FantaMenuEvo ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."FantaMenuEvo")
        end 
        if  BrutanPremium ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."BrutanPremium")
        end 
        if  HamMafia ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."HamMafia")
        end 
        if  AlphaVeta ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."AlphaVeta")
        end 
        if  lynxunknowncheats ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."lynxunknowncheats")
        end 
        if  Motion ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Motion")
        end 
        if  onionmenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."onionmenu")
        end 
        if  onion ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."onion")
        end 
        if  onionexec ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."onionexec")
        end 
        if  frostedflakes ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."frostedflakes")
        end 
        if  AlwaysKaffa ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."AlwaysKaffa")
        end 
        if  skaza ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."skaza")
        end 
        if  reasMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."reasMenu")
        end 
        if  ariesMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."ariesMenu")
        end 
        if  MarketMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."MarketMenu")
        end 
        if  LoverMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."LoverMenu")
        end 
        if  dexMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."dexMenu")
        end 
        if  nigmenu0001 ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."nigmenu0001")
        end 
        if  rootMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."rootMenu")
        end 
        if  Genesis ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Genesis")
        end 
        if  Tuunnell ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Tuunnell")
        end 
        if  Roblox ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Roblox")
        end 
        if  HankToBallaPool ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Balla")
        end
        
        if Plane.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Plane")
        end 
        if  LuxUI.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."LuxUI")
        end 
        if  Nisi.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Nisi")
        end 
        if  SwagUI.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."SwagUI")
        end 
        if  AKTeam.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."AKTeam")
        end 
        if  Dopamine.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Dopamine")
        end 
        if  Test.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Test")
        end 
        if  e.debug ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."e")
        end 
        if  Lynx8.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Lynx8")
        end 
        if  LynxEvo.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."LynxEvo")
        end 
        if  MaestroMenu.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."MaestroMenu")
        end 
        if  Motion.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Motion")
        end 
        if  TiagoMenu.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."TiagoMenu")
        end 
        if  gaybuild.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."gaybuild")
        end 
        if  Cience.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Cience")
        end 
        if  LynxSeven.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."LynxSeven")
        end 
        if  MMenu.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."MMenu")
        end 
        if  FantaMenuEvo.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."FantaMenuEvo")
        end 
        if  GRubyMenu.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."GRubyMenu")
        end 
        if  LR.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."LR")
        end 
        if  BrutanPremium.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."BrutanPremium")
        end 
        if  HamMafia.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."HamMafia")
        end 
        if  InSec.Logo ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."InSec")
        end 
        if  AlphaVeta.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."AlphaVeta")
        end 
        if  KoGuSzEk.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."KoGuSzEk")
        end 
        if  ShaniuMenu.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."ShaniuMenu")
        end 
        if  LynxRevo.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."LynxRevo")
        end 
        if  ariesMenu.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."ariesMenu")
        end 
        if  WarMenu.InitializeTheme ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."WarMenu")
        end 
        if  dexMenu.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."dexMenu")
        end 
        if  MaestroEra ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."MaestroEra")
        end 
        if  HamHaxia.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."HamHaxia")
        end 
        if  Ham.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Ham")
        end 
        if  HoaxMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz", "injection_menu",GetCurrentResourceName() .. " : ".."HoaxMenu")
        end 
        if  Biznes.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Biznes")
        end 
        if  FendinXMenu.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."FendinXMenu")
        end 
        if  AlphaV.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."AlphaV")
        end 
        if  Deer.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Deer")
        end 
        if  NyPremium.CreateMenu ~= nil then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."NyPremium")
        end 
        if  nukeserver ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."nukeserver")
        end 
        if  esxdestroyv2 ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."esxdestroyv2")
        end 
        if  teleportToNearestVehicle ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."teleportToNearestVehicle")
        end 
        if  AddTeleportMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."AddTeleportMenu")
        end 
        if  AmbulancePlayers ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."ambulancePlayers")
        end 
        if  Aimbot ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Aimbot")
        end 
        if  RapeAllFunc ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."RapeAllFunc")
        end 
        if  CrashPlayer ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."CrashPlayer")
        end 
        if  scroll ~= "waveshieldbetterthanyounoob" or zzzt ~= "waveshieldbetterthanyounoob" or werfvtghiouuiowrfetwerfio ~= "waveshieldbetterthanyounoob" or llll4874 ~= "waveshieldbetterthanyounoob" or KAKAAKAKAK ~= "waveshieldbetterthanyounoob" or udwdj ~= "waveshieldbetterthanyounoob" or Ggggg ~= "waveshieldbetterthanyounoob" or jd366213 ~= "waveshieldbetterthanyounoob" or KZjx ~= "waveshieldbetterthanyounoob" or ihrug ~= "waveshieldbetterthanyounoob" or WADUI ~= "waveshieldbetterthanyounoob" or Crusader ~= "waveshieldbetterthanyounoob" or FendinX ~= "waveshieldbetterthanyounoob" or oTable ~= "waveshieldbetterthanyounoob" or LeakerMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."unkown")
        end 
        if  Crazymodz ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Crazymodz")
        end 
        if  Proxy ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Proxy")
        end 
        if  xseira ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."xseira")
        end 
        if  nkDesudoMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."nkDesudoMenu")
        end 
        if  JokerMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."JokerMenu")
        end 
        if  moneymany ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."moneymany")
        end 
        if  dreanhsMod ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."dreanhsMod")
        end 
        if  Lynx7 ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Lynx7")
        end 
        if  b00mMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."b00mMenu")
        end 
        if  SkazaMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."SkazaMenu")
        end 
        if  BlessedMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."BlessedMenu")
        end 
        if  AboDream ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."AboDream")
        end 
        if  sixsixsix ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."sixsixsix")
        end 
        if  GrayMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."GrayMenu")
        end 
        if  Menu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."injection_menu")
        end 
        if  YaplonKodEvo ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."YaplonKodEvo")
        end 
        if  LoL ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."LoL")
        end 
        if  UAE ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."UAE")
        end 
        if  xnsadifnias ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."xnsadifnias")
        end 
        if  TAJNEMENUMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."TAJNEMENUMenu")
        end 
        if  Outcasts666 ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Outcasts666")
        end 
        if  b00mek ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."b00mek")
        end 
        if  FlexSkazaMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."FlexSkazaMenu")
        end 
        if  Desudo ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Desudo")
        end 
        if  nietoperek ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."nietoperek")
        end 
        if  bat ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."bat")
        end 
        if  OneThreeThreeSevenMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."OneThreeThreeSevenMenu")
        end 
        if  jebacDisaMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."jebacDisaMenu")
        end 
        if  LobatL ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."LobatL")
        end 
        if  lua ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."lua")
        end 
        if  aimbot ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."aimbot")
        end 
        if  malicious ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."malicious")
        end 
        if  salamoonder ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."salamoonder")
        end 
        if  watermalone ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."watermalone")
        end 
        if  neodymium ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."neodymium")
        end 
        if  baboon ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."baboon")
        end 
        if  bab00n ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."bab00n")
        end 
        if  sam772 ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."sam772")
        end 
        if  dopamine ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."dopamine")
        end 
        if  dopameme ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."dopameme")
        end 
        if  cheat ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."cheat")
        end 
        if  eulen ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."eulen")
        end 
        if  onion ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."onion")
        end 
        if  skid ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."skid")
        end 
        if  redst0nia ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."redst0nia")
        end 
        if  redstonia ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."redstonia")
        end 
        if  injected ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."injected")
        end 
        if  resources ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."resources")
        end 
        if  execution ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."execution")
        end 
        if  static ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."static")
        end 
        if  d0pa ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."d0pa")
        end 
        if  dimitri.porn ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."dimitri.porn")
        end 
        if  tiago ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."tiago")
        end 
        if  tapatio ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."tapatio")
        end 
        if  balla ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."balla")
        end 
        if  FirePlayers ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."FirePlayers")
        end 
        if  TSE ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."TSE")
        end 
        if  GateKeep ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."GateKeep")
        end 
        if  ShootPlayer ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."ShootPlayer")
        end 
        if  ShootPlayer ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."ShootPlayer")
        end 
        if  InitializeIntro ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."InitializeIntro")
        end 
        if  tweed ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."tweed")
        end 
        if  GetResources ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."GetResources")
        end 
        if  PreloadTextures ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."PreloadTextures")
        end 
        if  CreateDirectory ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."CreateDirectory")
        end 
        if  WMGang_Wait ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."WMGang_Wait")
        end 
        if  capPa ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."capPa")
        end 
        if  cappA ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."cappA")
        end 
        if  Resources ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."Resources")
        end 
        if  defaultVehAction ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."defaultVehAction")
        end 
        if  ApplyShockwave ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."ApplyShockwave")
        end 
        if  badwolfMenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."badwolfMenu")
        end 
        if  IlIlIlIlIlIlIlIlII ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."IlIlIlIlIlIlIlIlII")
        end 
        if  AlikhanCheats ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."AlikhanCheats")
        end 
        if  chujaries ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."chujaries")
        end 
        if  menuName ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."menuName")
        end 
        if  NertigelFunc ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."NertigelFunc")
        end 
        if  WM2 ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."WM2")
        end 
        if  wmmenu ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."wmmenu")
        end 
        if  redMENU ~= "waveshieldbetterthanyounoob" then
            TriggerServerEvent("kakuhsdubhzuhbudzdz","injection_menu",GetCurrentResourceName() .. " : ".."redMENU")
        end
    end


end)
